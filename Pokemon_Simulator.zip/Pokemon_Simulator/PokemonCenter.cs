﻿using System;

namespace Pokemon;

public class PokemonCenter
{
    private Trainer Trainer { get; set; }
    private Nurse Nurse { get; set; }
    
    public PokemonCenter(Trainer Trainer, Nurse Nurse)
    {
        this.Trainer = Trainer;
        this.Nurse = Nurse;
    }
    
    public void HealPokemon()
    {
        Console.WriteLine("test");
    }
}

public class Nurse : HealingStation
{

    public Nurse()
    {
        
    }
    
    
    // fill the slots of the healing station with dead pokemons
    public void FillStationSlots(Pokeball[] Slots, List<Pokeball> PokeballList)
    {
        Console.WriteLine("the nurse is filling the slots");
        
        // Console.WriteLine(Slots.Length);
        var Index = 0;
        foreach (var Pokeball in PokeballList )
        {
            // check if the slots are full
            if (Index == Slots.Length)
            {
                break;
            }
            
            // check if the pokemon is dead
            if (Pokeball.Pokemon.IsAlive == false)
            {
                Slots[Index] = Pokeball;
                Index++;
            }
            
        }
        
        
        //Remove the pokeballs from the pokebellt
        foreach (var Pokeball in Slots)
        {
            if (Pokeball != null)
            {
                PokeballList.Remove(Pokeball);
            }
        }

    }

    // return the pokeballs to the belt
    public void ReturnPokeballsToBellt(Pokeball[] Slots, List<Pokeball> PokeballList)
    {

        Console.WriteLine("the nurse is returning the pokeballs to the belt");
        private int Index = 0;
        foreach (var Pokeball in Slots)
        {
            if (Pokeball != null)
            {
                PokeballList.Add(Pokeball);
                Slots[Index] = null;
            }

            Index++;
        }
    }
    

    // check if all pokemons are healed
    public int CheckAllHealed(List<Pokeball> PokeballList)
    {
        private int NumberOfDeadPokemons = 0;
        foreach (var Pokeball in PokeballList)
        {
            if (Pokeball.Pokemon.IsAlive == false)
            {
                NumberOfDeadPokemons++;
            }
        }

        return NumberOfDeadPokemons;
    
    }
}


public class HealingStation
{
    public Pokeball[] Slots;
    private int MaxSlots = 4;
    // private Nurse Nurse;
    
    public HealingStation()
    {
        this.Slots = new Pokeball[MaxSlots];
        // this.Nurse = Nurse;
    }
    
    // heal the pokemons in the slots
    protected void HealPokemons()
    {
        Console.WriteLine("the nurse is healing the pokemons");
        foreach (var Pokeball in Slots)
        {
            if (Pokeball != null)
            {
                Pokeball.Pokemon.IsAlive = true;
            }
        }
    }
    
    
    // check if the healing station is operated by a nurse
    // public bool OperatedByNurse(Nurse nurse)
    // {
    //     return nurse is Nurse;
    // }

}
