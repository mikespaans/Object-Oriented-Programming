﻿using System;

namespace Pokemon;

public enum Strength_Weakness{
    Fire,
    Water,
    Leaf
}
